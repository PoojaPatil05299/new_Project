package com.example.bloodbank;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.Button;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;


public class SplashScreen extends Activity {
    private String filename = "activate.txt";
    private String filepath = "app/234.jpg";
    protected int _splashTime = 5000;
    File directory ;
    static String city="",out;
    private Activity mActivity;
    SplashScreen fmember;
    private Button mButtonDo;
    private ProgressDialog mProgressDialog,mProgressDialog1;
    private Context context;
    private static final int PERMISSION_REQUEST_CODE = 1;
    private AsyncTask mMyTask;
    public static int useridnew=0;
    private static final String TAG_RESULTS="result";
    private static final String TAG_ID = "id";
    private static final String TAG_NAME = "name";
    private static final String TAG_ADD ="address";
    static JSONArray peoples = null;
    //ListViewAdapter adapter;
    ContextWrapper contextWrapper;
    private Thread splashTread;
    File myInternalFile;
    JSONObject jsonobject;
    JSONArray jsonarray;
    ListView listview;
    static SharedPreferences sharedpreferences;
    ArrayList<HashMap<String, String>> personList;
    static String memberid;
    String myJSON;
    ArrayList<HashMap<String, String>> arraylist;
    public static SQLiteDatabase db;
    boolean flag=false;
    File myExternalFile;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        // setContentView(R.layout.splash);
        //requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        // super.onCreate(savedInstanceState);
        //setAnimation();
        setContentView(R.layout.splash);
        //getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.custom_title1);
        ContextWrapper contextWrapper = new ContextWrapper(getApplicationContext());
        mProgressDialog = new ProgressDialog(SplashScreen.this);
        mProgressDialog.setIndeterminate(true);
        // Progress dialog horizontal style
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        // Progress dialog title
        mProgressDialog.setTitle("AsyncTask");
        // Progress dialog message
        mProgressDialog.setMessage("Please wait, we are downloading your image file...");
        //  DownloadTask  mMyTask = (DownloadTask) new DownloadTask().execute(stringToURL("http://www.sspldemo.com/plasmadonation/plasmadonation/upload/1.png"));

        sharedpreferences= getSharedPreferences("plasmadonation", Context.MODE_PRIVATE);
        memberid= sharedpreferences.getString("user_id","");
        mProgressDialog = new ProgressDialog(SplashScreen.this);
        mProgressDialog.setIndeterminate(true);
        // Progress dialog horizontal style
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        // Progress dialog title
        mProgressDialog.setTitle("AsyncTask");
        // Progress dialog message
        mProgressDialog.setMessage("Please wait, we are downloading your image file...");
        //  DownloadTask  mMyTask = (DownloadTask) new DownloadTask().execute(stringToURL("http://www.sspldemo.com/plasmadonation/ONESS Garage/upload/1.png"));

        sharedpreferences= getSharedPreferences("plasmadonation", Context.MODE_PRIVATE);
        memberid= sharedpreferences.getString("user_id","");



            context = getApplicationContext();
            HttpTrustManager.allowAllSSL();

            SplashScreen sPlashScreen = this;
            try{
                String myData = "";
                new DownloadJSON(sPlashScreen).execute();
   /*  splashTread = new Thread() {
                @Override
                public void run() {
                    try {
                        synchronized (this) {
                          //  wait(_splashTime);
                        }

                    } catch (Exception e) {
                    } finally {
                        finish();
                        File f=new File(Environment.getExternalStorageDirectory() + "/SaraswatiDairy/");
                        if(!f.exists()){
                            f.mkdir();
                        }

                        //stop();
                    }
                }
            };*/
            }catch(Exception e){
                e.printStackTrace();
            }


    }
    private class DownloadJSON extends AsyncTask<Void, Void, Void> {
        public DownloadJSON(){

        }
        SplashScreen splash;
        public DownloadJSON(SplashScreen splash){
            this.splash=splash;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Create a progressdialog

            mProgressDialog1 = new ProgressDialog(splash);
            // Set progressdialog title
            mProgressDialog1.setTitle("Plasma Donation");
            // Set progressdialog message
            mProgressDialog1.setMessage("Loading...");
            mProgressDialog1.setIndeterminate(false);
            // Show progressdialog
            mProgressDialog1.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected Void doInBackground(Void... params1) {
            // Create an array
            //workshop bike service


            return null;
        }

        @Override
        protected void onPostExecute(Void args) {
            // Locate the listview in listview_main.xml
            sharedpreferences = getSharedPreferences("plasmadonation", Context.MODE_PRIVATE);
            String val = sharedpreferences.getString("isLogged", "");
            if (val.equals("1")) {
                Intent i = new Intent();
                //i.setClass(sPlashScreen, Dashboard.class);
                i.setClass(SplashScreen.this, DonorList.class);
                startActivity(i);
            } else {


                Intent i = new Intent();
                // i.setClass(sPlashScreen, Login.class);
                i.setClass(SplashScreen.this, HomeActivity.class);
                startActivity(i);
            }
            //// Close the progressdialog
            mProgressDialog1.dismiss();
        }
    }



}
